# 16x16 RPG characters `v3.0`

16x16px RPG character sprite sheet for up to down games.

This asset pack has been downloaded from https://route1rodent.itch.io/16x16-rpg-character-sprite-sheet

Adapted from opengameart.org 's "[NES-Style RPG Characters](https://opengameart.org/content/nes-style-rpg-characters)" and "[More NES-style RPG Characters](https://opengameart.org/content/more-nes-style-rpg-characters)", with additional content made by [@route1rodent](https://route1rodent.itch.io).

## License

16x16 RPG character sprite sheet (c) by @route1rodent

"16x16 RPG character sprite sheet" is licensed under a
Creative Commons Attribution-ShareAlike 3.0 Unported License (CC BY-SA 3.0).

You should have received a copy of the license along with this
work. If not, see http://creativecommons.org/licenses/by-sa/3.0/.


## Credits

Maintained by @route1rodent:

- itch.io: https://route1rodent.itch.io
- Twitter: https://twitter.com/route1rodent
- Github: https://github.com/itsjavi
- Blog: https://blog.itsjavi.com
