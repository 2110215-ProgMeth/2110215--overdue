package interfaces;

import battleEntity.battleUnit.BaseUnit;

public interface Consumable {
    public void use(BaseUnit target);
}
