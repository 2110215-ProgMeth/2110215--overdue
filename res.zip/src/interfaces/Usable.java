package interfaces;

import battleEntity.battleUnit.BaseUnit;

public interface Usable {
    public void use(BaseUnit target);
}
