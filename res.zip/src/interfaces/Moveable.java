package interfaces;

public interface Moveable {
    public void updateCoordinate();
}
